import tensorflow as tf
from tensorflow.keras.layers import LayerNormalization, Dense, MultiHeadAttention, Input, Flatten
from tensorflow.keras import Model

def build_transformer(input_shape):
    inputs = Input(shape=input_shape)
    attn = MultiHeadAttention(num_heads=2, key_dim=16)(inputs, inputs)
    x = LayerNormalization()(inputs + attn)
    dense = Dense(32, activation="relu")(x)
    x = LayerNormalization()(x + dense)
    x = Flatten()(x)
    outputs = Dense(1)(x)
    model = Model(inputs, outputs)
    model.compile(optimizer="adam", loss="mse")
    return model
