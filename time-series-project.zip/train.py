import pandas as pd
import numpy as np
from sklearn.preprocessing import MinMaxScaler
from lstm_model import build_lstm
from transformer_model import build_transformer
import shap

df = pd.read_csv("data.csv")

scaler = MinMaxScaler()
features = df[['feature1', 'feature2']]
target = df['target']
scaled_features = scaler.fit_transform(features)

window = 3
X, y = [], []
for i in range(len(scaled_features) - window):
    X.append(scaled_features[i:i+window])
    y.append(target[i+window])
X, y = np.array(X), np.array(y)

model = build_lstm((window, 2))
# model = build_transformer((window, 2))

model.fit(X, y, epochs=10, verbose=1)

explainer = shap.DeepExplainer(model, X[:50])
shap_values = explainer.shap_values(X[:1])
print("Training complete and explainability generated.")
