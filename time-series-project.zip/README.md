# Advanced Time Series Forecasting with LSTM & Transformer

This project demonstrates advanced multivariate time series forecasting using:
- LSTM Neural Network
- Transformer Encoder Model
- Explainability using SHAP

## Project Files
- `data.csv`
- `lstm_model.py`
- `transformer_model.py`
- `train.py`
- `requirements.txt`

## Steps to Run
```
pip install -r requirements.txt
python train.py
```
